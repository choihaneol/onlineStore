import { Typography } from "@mui/material";

export default function HamePage() {

    return (
        <Typography variant='h2'>
            Home Page
        </Typography>
    )
}