import { Typography } from "@mui/material";

export default function CheckouPage()
{
    return (
        <Typography variant='h3'>
            Only logged in users should be able to see this!
        </Typography>
    )

}